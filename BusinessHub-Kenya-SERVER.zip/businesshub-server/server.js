/**
 * BusinessHub Kenya — multi-device API server
 * Zero npm dependencies (Node 18+). Data in ./data/db.json
 *
 * Start:  node server.js
 * Open:   http://localhost:3847
 *
 * Admin sees all clients who register against THIS server from any device.
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const PORT = Number(process.env.PORT)||3847;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const PUBLIC = path.join(ROOT, 'public');

const DEFAULT_PLANS = {
  FREE: { name: 'Free', price: 0, bizLimit: 1, label: 'Free trial' },
  PRO: { name: 'Pro', price: 1500, bizLimit: 3, label: 'Pro · KES 1,500/mo' },
  BUSINESS: { name: 'Business', price: 4500, bizLimit: 10, label: 'Business · KES 4,500/mo' }
};

function uid() {
  return crypto.randomBytes(8).toString('hex');
}

function today() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

function addDays(dayStr, n) {
  const p = String(dayStr || today()).slice(0, 10).split('-');
  const d = new Date(+p[0], +p[1] - 1, +p[2]);
  d.setDate(d.getDate() + n);
  const pad = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function emptyDb() {
  return {
    users: [],
    sessions: {},
    businesses: [],
    plans: JSON.parse(JSON.stringify(DEFAULT_PLANS)),
    platform: {
      company: 'BusinessHub Kenya',
      ownerName: '',
      phone: '',
      email: 'admin@businesshub.ke',
      address: '',
      city: 'Nairobi',
      country: 'Kenya',
      mpesaTill: '',
      paybill: '',
      bankName: '',
      bankAccount: '',
      supportEmail: '',
      website: '',
      notes: ''
    },
    notices: [],
    adminEmail: 'admin@businesshub.ke',
    platformUpdate: null
  };
}

function loadDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const d = emptyDb();
    fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 2));
    return d;
  }
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  } catch {
    return emptyDb();
  }
}

function saveDb(db) {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function json(res, status, body) {
  const data = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS'
  });
  res.end(data);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function tokenFrom(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7).trim();
  return null;
}

function userFrom(req, db) {
  const t = tokenFrom(req);
  if (!t || !db.sessions[t]) return null;
  const sid = db.sessions[t];
  return db.users.find((u) => u.id === sid) || null;
}

function isAdmin(u, db) {
  if (!u) return false;
  return u.role === 'admin' || u.email === (db.adminEmail || 'admin@businesshub.ke');
}

function publicUser(u) {
  if (!u) return null;
  return { id: u.id, email: u.email, name: u.name || '', role: u.role || 'owner', phone: u.phone || '' };
}

function emptyBiz(ownerId, extra) {
  return Object.assign(
    {
      id: uid(),
      ownerId,
      name: '',
      phone: '',
      address: '',
      payinfo: '',
      currency: 'KES',
      categories: [],
      categoryLabel: '',
      color: '#0d9488',
      salesPin: '',
      plan: 'FREE',
      onlineStore: true,
      createdAt: today(),
      trialEndsAt: addDays(today(), 3),
      products: [],
      cart: [],
      orders: [],
      customers: [],
      quotations: [],
      expenses: [],
      purchases: [],
      orderN: 0,
      qtN: 0,
      purN: 0,
      onlineN: 0,
      payments: { provider: 'mpesa' },
      suspended: false
    },
    extra || {}
  );
}

async function handleApi(req, res, pathname) {
  const db = loadDb();
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS'
    });
    return res.end();
  }

  // Health
  if (pathname === '/api/health' && method === 'GET') {
    return json(res, 200, { ok: true, clients: db.users.filter((u) => u.role !== 'admin').length, businesses: db.businesses.length });
  }

  // Register
  if (pathname === '/api/register' && method === 'POST') {
    const body = await readBody(req);
    const email = String(body.email || '').toLowerCase().trim();
    const password = String(body.password || '');
    const name = String(body.name || '');
    if (!email || password.length < 6) return json(res, 400, { error: 'Email and password (min 6) required' });
    if (db.users.find((u) => u.email === email)) return json(res, 409, { error: 'Email already registered' });
    const adminMail = (db.adminEmail || 'admin@businesshub.ke').toLowerCase();
    if (email === adminMail || email === 'admin@businesshub.ke') {
      return json(res, 400, { error: 'Use /api/admin/register for platform admin' });
    }
    const user = { id: uid(), email, password, name, role: 'owner', phone: body.phone || '' };
    db.users.push(user);
    const token = uid() + uid();
    db.sessions[token] = user.id;
    saveDb(db);
    return json(res, 201, { token, user: publicUser(user) });
  }

  // Admin register (once)
  if (pathname === '/api/admin/register' && method === 'POST') {
    const body = await readBody(req);
    const email = String(body.email || '').toLowerCase().trim();
    const password = String(body.password || '');
    if (!email || password.length < 6) return json(res, 400, { error: 'Email and password required' });
    if (db.users.some((u) => u.role === 'admin' || u.email === (db.adminEmail || 'admin@businesshub.ke'))) {
      return json(res, 409, { error: 'Platform admin already exists' });
    }
    if (db.users.find((u) => u.email === email)) return json(res, 409, { error: 'Email already registered' });
    db.adminEmail = email;
    if (!db.platform) db.platform = {};
    db.platform.email = email;
    db.platform.ownerName = body.name || '';
    db.platform.phone = body.phone || '';
    db.platform.company = body.company || db.platform.company || 'BusinessHub Kenya';
    const user = { id: uid(), email, password, name: body.name || '', role: 'admin', phone: body.phone || '' };
    db.users.push(user);
    const token = uid() + uid();
    db.sessions[token] = user.id;
    saveDb(db);
    return json(res, 201, { token, user: publicUser(user) });
  }

  // Login
  if (pathname === '/api/login' && method === 'POST') {
    const body = await readBody(req);
    const email = String(body.email || '').toLowerCase().trim();
    const password = String(body.password || '');
    const user = db.users.find((u) => u.email === email && u.password === password);
    if (!user) return json(res, 401, { error: 'Invalid email or password' });
    if (body.adminOnly && !isAdmin(user, db)) return json(res, 403, { error: 'Not a platform admin account' });
    if (!body.adminOnly && isAdmin(user, db) && body.clientOnly) {
      return json(res, 403, { error: 'Use admin login for this account' });
    }
    const token = uid() + uid();
    db.sessions[token] = user.id;
    saveDb(db);
    return json(res, 200, { token, user: publicUser(user), isAdmin: isAdmin(user, db) });
  }

  // Logout
  if (pathname === '/api/logout' && method === 'POST') {
    const t = tokenFrom(req);
    if (t && db.sessions[t]) {
      delete db.sessions[t];
      saveDb(db);
    }
    return json(res, 200, { ok: true });
  }

  // Me
  if (pathname === '/api/me' && method === 'GET') {
    const u = userFrom(req, db);
    if (!u) return json(res, 401, { error: 'Unauthorized' });
    return json(res, 200, { user: publicUser(u), isAdmin: isAdmin(u, db), plans: db.plans, platformUpdate: db.platformUpdate });
  }

  // Notices (clients)
  if (pathname === '/api/notices' && method === 'GET') {
    const u = userFrom(req, db);
    if (!u) return json(res, 401, { error: 'Unauthorized' });
    return json(res, 200, { notices: db.notices || [], platformUpdate: db.platformUpdate });
  }

  // List my businesses
  if (pathname === '/api/businesses' && method === 'GET') {
    const u = userFrom(req, db);
    if (!u) return json(res, 401, { error: 'Unauthorized' });
    if (isAdmin(u, db)) {
      return json(res, 200, { businesses: db.businesses });
    }
    const list = db.businesses.filter((b) => b.ownerId === u.id);
    return json(res, 200, { businesses: list });
  }

  // Create business
  if (pathname === '/api/businesses' && method === 'POST') {
    const u = userFrom(req, db);
    if (!u) return json(res, 401, { error: 'Unauthorized' });
    if (isAdmin(u, db)) return json(res, 403, { error: 'Admin cannot create client businesses here' });
    const body = await readBody(req);
    const mine = db.businesses.filter((b) => b.ownerId === u.id);
    const planKey = mine[0]?.plan || 'FREE';
    const limit = (db.plans[planKey] || DEFAULT_PLANS.FREE).bizLimit || 1;
    if (mine.length >= limit) return json(res, 403, { error: 'Plan business limit reached' });
    const b = emptyBiz(u.id, body);
    if (!b.trialEndsAt) b.trialEndsAt = addDays(today(), 3);
    db.businesses.push(b);
    saveDb(db);
    return json(res, 201, { business: b });
  }

  // Get / update one business
  const bizMatch = pathname.match(/^\/api\/businesses\/([^/]+)$/);
  if (bizMatch) {
    const id = bizMatch[1];
    const u = userFrom(req, db);
    if (!u) return json(res, 401, { error: 'Unauthorized' });
    const b = db.businesses.find((x) => x.id === id);
    if (!b) return json(res, 404, { error: 'Not found' });
    const allowed = isAdmin(u, db) || b.ownerId === u.id;
    if (!allowed) return json(res, 403, { error: 'Forbidden' });

    if (method === 'GET') return json(res, 200, { business: b });

    if (method === 'PUT' || method === 'PATCH') {
      const body = await readBody(req);
      // Clients cannot change plan to paid without payment flow — allow plan field; admin always can
      if (!isAdmin(u, db)) {
        // owner updates full business payload (products, orders, etc.)
        const keep = { id: b.id, ownerId: b.ownerId };
        Object.assign(b, body, keep);
      } else {
        // admin: only management fields
        ['plan', 'suspended', 'trialEndsAt', 'trialExtended', 'name'].forEach((k) => {
          if (body[k] !== undefined) b[k] = body[k];
        });
        if (body.plan && body.plan !== 'FREE') {
          b.planPaidAt = today();
          b.planReceipt = b.planReceipt || 'ADMIN-' + Date.now();
        }
      }
      saveDb(db);
      return json(res, 200, { business: b });
    }

    if (method === 'DELETE') {
      if (!isAdmin(u, db) && b.ownerId !== u.id) return json(res, 403, { error: 'Forbidden' });
      db.businesses = db.businesses.filter((x) => x.id !== id);
      saveDb(db);
      return json(res, 200, { ok: true });
    }
  }

  // Admin overview
  if (pathname === '/api/admin/overview' && method === 'GET') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const clients = db.users.filter((x) => x.role !== 'admin' && x.email !== db.adminEmail);
    const planCounts = {};
    db.businesses.forEach((b) => {
      const k = b.plan || 'FREE';
      planCounts[k] = (planCounts[k] || 0) + 1;
    });
    return json(res, 200, {
      clients: clients.map(publicUser),
      businesses: db.businesses.map((b) => ({
        id: b.id,
        name: b.name,
        ownerId: b.ownerId,
        plan: b.plan,
        suspended: !!b.suspended,
        createdAt: b.createdAt,
        trialEndsAt: b.trialEndsAt,
        onlineStore: b.onlineStore
      })),
      planCounts,
      plans: db.plans,
      platform: db.platform,
      notices: db.notices,
      totals: {
        clients: clients.length,
        businesses: db.businesses.length,
        suspended: db.businesses.filter((b) => b.suspended).length
      }
    });
  }

  // Admin update client password
  if (pathname === '/api/admin/users/reset-password' && method === 'POST') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    const client = db.users.find((x) => x.id === body.userId);
    if (!client) return json(res, 404, { error: 'User not found' });
    client.password = body.password || '1234';
    saveDb(db);
    return json(res, 200, { ok: true });
  }

  // Admin delete client
  if (pathname === '/api/admin/users' && method === 'DELETE') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    const id = body.userId;
    db.users = db.users.filter((x) => x.id !== id);
    db.businesses = db.businesses.filter((b) => b.ownerId !== id);
    Object.keys(db.sessions).forEach((t) => {
      if (db.sessions[t] === id) delete db.sessions[t];
    });
    saveDb(db);
    return json(res, 200, { ok: true });
  }

  // Admin plans
  if (pathname === '/api/admin/plans' && method === 'PUT') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    if (body.plans) db.plans = body.plans;
    saveDb(db);
    return json(res, 200, { plans: db.plans });
  }

  // Admin platform profile
  if (pathname === '/api/admin/platform' && method === 'PUT') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    db.platform = Object.assign(db.platform || {}, body);
    if (body.email) db.adminEmail = String(body.email).toLowerCase().trim();
    saveDb(db);
    return json(res, 200, { platform: db.platform });
  }

  // Admin notices
  if (pathname === '/api/admin/notices' && method === 'POST') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    const notice = { id: uid(), title: body.title || '', body: body.body || '', date: today() };
    if (!db.notices) db.notices = [];
    db.notices.push(notice);
    db.platformUpdate = { at: new Date().toISOString(), title: notice.title, body: notice.body };
    saveDb(db);
    return json(res, 201, { notice });
  }

  if (pathname === '/api/admin/notices' && method === 'DELETE') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    const body = await readBody(req);
    db.notices = (db.notices || []).filter((n) => n.id !== body.id);
    saveDb(db);
    return json(res, 200, { ok: true });
  }

  // Online public shops (no auth)
  if (pathname === '/api/public/shops' && method === 'GET') {
    const shops = db.businesses
      .filter((b) => b.onlineStore !== false && b.name && !b.suspended)
      .map((b) => ({
        id: b.id,
        name: b.name,
        color: b.color,
        phone: b.phone,
        address: b.address,
        categoryLabel: b.categoryLabel,
        productCount: (b.products || []).filter((p) => p.active !== false && (p.stock || 0) > 0).length
      }));
    return json(res, 200, { shops });
  }

  if (pathname.match(/^\/api\/public\/shops\/[^/]+$/) && method === 'GET') {
    const id = pathname.split('/').pop();
    const b = db.businesses.find((x) => x.id === id);
    if (!b || b.onlineStore === false || b.suspended) return json(res, 404, { error: 'Shop not found' });
    return json(res, 200, {
      shop: {
        id: b.id,
        name: b.name,
        color: b.color,
        phone: b.phone,
        address: b.address,
        categoryLabel: b.categoryLabel,
        products: (b.products || []).filter((p) => p.active !== false && (p.stock || 0) > 0),
        payments: { till: b.payments?.till || b.payinfo, provider: b.payments?.provider }
      }
    });
  }

  // Public place online order
  if (pathname.match(/^\/api\/public\/shops\/[^/]+\/orders$/) && method === 'POST') {
    const id = pathname.split('/')[4];
    const b = db.businesses.find((x) => x.id === id);
    if (!b || b.onlineStore === false || b.suspended) return json(res, 404, { error: 'Shop not found' });
    const body = await readBody(req);
    b.onlineN = (b.onlineN || 0) + 1;
    b.orderN = (b.orderN || 0) + 1;
    const items = body.items || [];
    let total = 0;
    items.forEach((it) => {
      total += Number(it.price) * Number(it.qty);
      const p = (b.products || []).find((x) => x.id === it.product_id);
      if (p) p.stock = Math.max(0, (p.stock || 0) - Number(it.qty));
    });
    const order = {
      id: uid(),
      number: 'WEB-' + String(b.onlineN).padStart(4, '0'),
      date: today(),
      items,
      total: Math.round(total * 100) / 100,
      status: body.status || 'PENDING',
      payMethod: body.payMethod || 'mpesa',
      phone: body.phone,
      customerName: body.customerName,
      fulfillment: body.fulfillment || 'pickup',
      deliveryAddress: body.deliveryAddress || '',
      receipt: body.receipt || 'PENDING-PAY',
      source: 'online'
    };
    if (!b.orders) b.orders = [];
    b.orders.push(order);
    saveDb(db);
    return json(res, 201, { order });
  }

  // Full DB export (admin)
  if (pathname === '/api/admin/backup' && method === 'GET') {
    const u = userFrom(req, db);
    if (!u || !isAdmin(u, db)) return json(res, 403, { error: 'Admin only' });
    return json(res, 200, {
      type: 'businesshub_admin_backup',
      version: 1,
      exportedAt: new Date().toISOString(),
      data: {
        users: db.users,
        businesses: db.businesses,
        plans: db.plans,
        platform: db.platform,
        notices: db.notices,
        adminEmail: db.adminEmail
      }
    });
  }

  return json(res, 404, { error: 'Not found', path: pathname });
}

function contentType(file) {
  const ext = path.extname(file).toLowerCase();
  return (
    {
      '.html': 'text/html; charset=utf-8',
      '.js': 'application/javascript',
      '.css': 'text/css',
      '.json': 'application/json',
      '.png': 'image/png',
      '.svg': 'image/svg+xml',
      '.ico': 'image/x-icon'
    }[ext] || 'application/octet-stream'
  );
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    let pathname = url.pathname;

    if (pathname.startsWith('/api/')) {
      return await handleApi(req, res, pathname);
    }

    // Static files
    if (pathname === '/') pathname = '/index.html';
    const safe = path.normalize(pathname).replace(/^(\.\.[/\\])+/, '');
    const file = path.join(PUBLIC, safe);
    if (!file.startsWith(PUBLIC)) {
      res.writeHead(403);
      return res.end('Forbidden');
    }
    if (fs.existsSync(file) && fs.statSync(file).isFile()) {
      res.writeHead(200, { 'Content-Type': contentType(file) });
      return fs.createReadStream(file).pipe(res);
    }
    // SPA fallback
    const index = path.join(PUBLIC, 'index.html');
    if (fs.existsSync(index)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(index).pipe(res);
    }
    res.writeHead(404);
    res.end('Not found. Place the app in public/index.html');
  } catch (e) {
    console.error(e);
    json(res, 500, { error: String(e.message || e) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('  BusinessHub Kenya server running');
  console.log('  --------------------------------');
  console.log(`  Local:   http://localhost:${PORT}`);
  console.log(`  Network: http://<your-ip>:${PORT}`);
  console.log(`  Data:    ${DB_FILE}`);
  console.log('');
  console.log('  Clients and admin on ANY device use the same database.');
  console.log('');
});
