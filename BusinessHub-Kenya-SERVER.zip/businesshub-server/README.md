# BusinessHub Kenya — Server (shared database)

Run this server so **you and your clients use one database**.
Admin on your laptop can see clients who register from their phones.

## Requirements
- Node.js 18 or newer (https://nodejs.org)

## Start

```bash
cd businesshub-server
node server.js
```

Open: **http://localhost:3847**

## On the same Wi‑Fi (phone + computer)

1. Find your computer IP (e.g. `192.168.1.12`)
2. Start the server
3. On the phone open: `http://192.168.1.12:3847`

## Internet (from far away)

Deploy this folder to any host that runs Node:

- Railway, Render, VPS, Ubuntu server
- Set `PORT` if required
- Open the public URL — all devices use the same `data/db.json`

## Data

All users and businesses are stored in:

`data/db.json`

Back up this file regularly.

## Modes

| How you open the app | Mode |
|----------------------|------|
| `node server.js` then browser to localhost | **Server DB** — multi-device |
| Double-click HTML file | **Local only** — one browser |

## Admin

1. Open the app via the server URL  
2. **Admin register** once  
3. Clients register from any device on the same server  
4. You see them under **Clients** / **Businesses**
