# Deploy BusinessHub Kenya permanently (free)

## Option A — Railway (recommended, ~3 minutes)

1. Go to https://railway.app and sign up (GitHub login is fine).
2. Click **New Project** → **Deploy from GitHub repo**  
   OR **Empty Project** → **Add Service** → **Empty Service**.
3. Upload / connect this `businesshub-server` folder:
   - Easiest: create a GitHub repo, push this folder, deploy from GitHub.
   - Or use Railway CLI: `npm i -g @railway/cli` then `railway login` → `railway up`
4. Railway sets `PORT` automatically. Start command: `node server.js`
5. Open **Settings → Networking → Generate Domain**
6. Your permanent site: `https://something.up.railway.app`

## Option B — Render

1. Go to https://render.com and sign up.
2. **New → Web Service**
3. Connect the GitHub repo with this folder (or upload).
4. Runtime: **Node**
5. Build command: leave empty (or `echo ok`)
6. Start command: `node server.js`
7. Free plan → **Create Web Service**
8. Permanent URL: `https://businesshub-kenya.onrender.com` (example)

## After deploy

1. Open your permanent HTTPS URL
2. Badge should show **Server DB**
3. **Admin register** once
4. Share the same URL with clients — you see them from anywhere

## Custom domain (optional)

In Railway or Render → Domains → add `businesshub.com` (or any domain you own) and follow DNS instructions.

## Backups

Download Admin → Backup regularly, or download `data/db.json` from the host.
